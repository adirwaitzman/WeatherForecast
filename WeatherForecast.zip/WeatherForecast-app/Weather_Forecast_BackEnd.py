import requests
from flask import Response
import boto3


def convert_to_geolocation(location):
    result = requests.get(
        f"https://geocoding-api.open-meteo.com/v1/search?name={location}&count=1&language=en&format=json").json()
    if 'results' not in result.keys():
        return None, None, None, None
    latitude = result['results'][0]['latitude']
    longitude = result['results'][0]['longitude']
    name = result['results'][0]['name']
    country = result['results'][0]['country']
    # timezone = result['results'][0]['timezone']
    return latitude, longitude, name, country


def get_forecast(latitude, longitude):
    result = requests.get(
        f"https://api.open-meteo.com/v1/forecast?latitude={latitude}&longitude={longitude}&daily=temperature_2m_max,"
        f"temperature_2m_min,relative_humidity_2m_mean").json()

    return result


def parse_data(data):
    seven_day_data = {}

    for i in range(len(data['daily']['time'])):
        seven_day_data[i + 1] = []
        seven_day_data[i + 1].append(data['daily']['time'][i])
        seven_day_data[i + 1].append(data['daily']['temperature_2m_max'][i])
        seven_day_data[i + 1].append(data['daily']['temperature_2m_min'][i])
        seven_day_data[i + 1].append(data['daily']['relative_humidity_2m_mean'][i])

    # for key in seven_day_data.keys():
    #     print(key, seven_day_data[key])

    return seven_day_data


def convert_location_to_forecast(user_location):
    user_location_latitude, user_location_longitude, user_location_name, user_location_country \
        = convert_to_geolocation(user_location)
    if user_location_name is None:
        return None

    location_data = get_forecast(user_location_latitude, user_location_longitude)
    return parse_data(location_data), user_location_name, user_location_country


def download_image():
    s3_client = boto3.client('s3')
    obj = s3_client.get_object(Bucket="waitzman.com", Key="sky.jpeg")
    return Response(obj["Body"].read(), mimetype='Content-Type',
                    headers={'Content-Disposition': 'attachment; filename=sky.jpeg'})


# def dynamodb_send_item(data):
#     dynamodb = boto3.resource('dynamodb')
#     table = dynamodb.Table('WeatherForecast')
#
#     def convert_to_dynamodb_type(value):
#         if isinstance(value, list):
#             return {'L': [convert_to_dynamodb_type(item) for item in value]}
#         elif isinstance(value, int):
#             return {'N': str(value)}
#         elif isinstance(value, float):
#             return {'N': str(value)}
#         elif isinstance(value, bool):
#             return {'BOOL': value}
#         else:
#             return {'S': str(value)}
#
#     for key in data.keys():
#         for i in range(len(data[key])):
#             data[key][i] = convert_to_dynamodb_type(data[key][i])
#         data[convert_to_dynamodb_type(key)] = data[key]
#
#
#     response = table.put_item(
#         Item=data
#     )
#     return response


def dynamodb_send_item(items, location_country):
    dynamodb = boto3.client('dynamodb', region_name='eu-north-1')

    def convert_to_dynamodb_type(value):
        if isinstance(value, list):
            return {'L': [convert_to_dynamodb_type(item) for item in value]}
        elif isinstance(value, int):
            return {'N': str(value)}
        elif isinstance(value, float):
            return {'N': str(value)}
        elif isinstance(value, bool):
            return {'BOOL': value}
        else:
            return {'S': str(value)}
    dyn_items = []
    for key, value in items.items():
        dyn_items.append(convert_to_dynamodb_type(value))

    # for i in range(7):
    #     items[f"{str(i+1)} day"] = items[i+1]
    #     del items[i+1]

    response = dynamodb.put_item(
        TableName="WeatherForecast",
        Item={
            "data": {"S": str(location_country)},
            "weather": {"L": dyn_items}
        }
    )
    # response = None
    return response


if __name__ == "__main__":
    data, location_name, location_country = convert_location_to_forecast("bat yam")
    print(data)
    dynamodb_send_item(data, location_country)
    print(data)
