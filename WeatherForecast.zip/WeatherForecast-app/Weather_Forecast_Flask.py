from flask import Flask, render_template, request, redirect
from Weather_Forecast_BackEnd import *
from _socket import gethostname
import boto3

app = Flask(__name__)


@app.route('/', methods=["GET", "POST"])
def home_page():
    data = None
    host = gethostname()
    if request.method == "POST":
        data, location_name, location_country = convert_location_to_forecast(request.form.get("location_input"))
        return render_template("Weather_Forecast.html", data=data, location=location_name,
                               country=location_country, host=host)

    return render_template("Weather_Forecast.html", data=data, host=host)


@app.route("/download")
def download():
    return download_image()


@app.route("/dynamodb", methods=['POST'])
def dynamodb():
    data, location_name, location_country = convert_location_to_forecast(request.form.get("location_input"))
    return dynamodb_send_item(data, location_name)
 #   return redirect('.')


if __name__ == "__main__":
    app.run(debug=True)
